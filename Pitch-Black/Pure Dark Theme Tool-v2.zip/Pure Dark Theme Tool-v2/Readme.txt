Author: Ceofix
www.ceofix.net
---------------- Pure Dark Theme Tool V2 ---------------------
Thursday, 17 November 2022

Changelog:

1. [Added] - Ability to take the backup wherever the user wants feature
2. [Added] - Show color on title bar , Hide color on title bar , Active Window color , Turn on inactive window, Change title text color, Change inactive title text, Turn on original reset ,  RGB - BGR color codes chart , User logout and refresh features
3. [Fixed] - Some bugs in Windows 11

MD5	: 2b733beb4a3f39e2fabdbecb4adff574
SHA-1	: eaf46bc647e6ad5263cf6a64071e1c3432b13b60
SHA-256	: c2bbb7a703aa1093639eea7072ac1881aa6717bdccadaece2608b73bf0c0c775

---------------- Pure Dark Theme Tool V1 ---------------------

Monday, 11 January 2021

Pure Dark Theme Tool is a Portable freeware that Makes the Start Menu, Taskbar, Action center,Title Bars and Window borders pure black

MD5	: 387835ca6d7b74a9d78d6e69aad0dc07
SHA-1	: ca93084ebf026bfc1995a16a18d4e9003f6175db
SHA-256	: 5ed3b79097f629f468cd6d1eb486c9d40c7c1f21ece84ec0d2519bb35e15130a